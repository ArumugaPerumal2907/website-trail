import { ThemeProvider } from '@/components/theme-provider';
import { Layout } from '@/components/layout';
import { Home } from '@/components/home';

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <Layout>
        <Home />
      </Layout>
    </ThemeProvider>
  );
}

export default App;