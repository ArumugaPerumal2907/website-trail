import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useScrollSpy } from "@/lib/hooks/use-scroll-spy";

const sections = [
  { id: "home", label: "Home" },
  { id: "objective", label: "Objective" },
  { id: "education", label: "Education" },
  { id: "experience", label: "Experience" },
  { id: "projects", label: "Projects" },
  { id: "achievements", label: "Achievements" },
  { id: "certifications", label: "Certifications" },
  { id: "skills", label: "Skills" }
];

interface NavigationMenuProps {
  className?: string;
}

export function NavigationMenu({ className }: NavigationMenuProps) {
  const activeSection = useScrollSpy(sections.map(s => s.id));

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const header = document.querySelector('header');
      const headerHeight = header?.offsetHeight || 0;
      const elementPosition = element.getBoundingClientRect().top + window.scrollY;
      
      window.scrollTo({
        top: elementPosition - headerHeight - 20,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav 
      className={cn(
        "flex items-center gap-2",
        "md:bg-background/50 md:backdrop-blur-sm md:px-4 md:py-2 md:rounded-full md:border md:shadow-sm",
        className
      )}
      role="navigation"
      aria-label="Main navigation"
    >
      {sections.map(({ id, label }) => (
        <motion.button
          key={id}
          onClick={() => scrollToSection(id)}
          className={cn(
            "relative w-full md:w-auto px-4 py-2 text-sm font-medium rounded-full transition-all",
            "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
            "hover:text-primary-foreground",
            activeSection === id 
              ? "bg-gradient-to-r from-primary via-purple-500 to-pink-500 text-white shadow-md"
              : "text-muted-foreground hover:bg-primary/10"
          )}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          aria-current={activeSection === id ? "page" : undefined}
        >
          {label}
        </motion.button>
      ))}
    </nav>
  );
}