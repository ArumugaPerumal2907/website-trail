import { Briefcase, ExternalLink } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { SectionHeader } from '../ui/section-header';
import { featuredProject } from '@/data/projects';

export function ProjectsSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Featured Project" icon={Briefcase} />
      <Card className="p-6 group hover:shadow-lg transition-all duration-300">
        <div className="flex justify-between items-start">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold group-hover:text-primary transition-colors">
              {featuredProject.title}
            </h3>
            <p className="text-muted-foreground">
              {featuredProject.description}
            </p>
            <div className="flex gap-2 flex-wrap">
              {featuredProject.features.map((feature) => (
                <Badge 
                  key={feature} 
                  variant="secondary" 
                  className="hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  {feature}
                </Badge>
              ))}
            </div>
          </div>
          <a
            href={featuredProject.projectUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:text-primary/80 transition-colors"
          >
            <Button variant="ghost" size="icon">
              <ExternalLink className="h-4 w-4" />
            </Button>
          </a>
        </div>
      </Card>
    </section>
  );
}