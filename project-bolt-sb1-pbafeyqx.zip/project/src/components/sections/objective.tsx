import { Target } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { SectionHeader } from '../ui/section-header';

export function ObjectiveSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Objective" icon={Target} />
      <Card className="p-6 relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent" />
        <div className="relative prose prose-neutral dark:prose-invert max-w-none">
          <p className="text-lg leading-relaxed">
            To provide enthusiastic work by leveraging my skills for company development. 
            As an <span className="text-primary font-medium">autodidact learner</span>, 
            I aim to continuously acquire contemporary technologies, update myself, and 
            enhance project outcomes through effective planning and management.
          </p>
        </div>
      </Card>
    </section>
  );
}