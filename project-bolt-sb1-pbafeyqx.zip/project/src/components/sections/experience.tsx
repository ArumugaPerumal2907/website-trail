import { Briefcase } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SectionHeader } from '../ui/section-header';
import { motion } from 'framer-motion';

interface Experience {
  title: string;
  company: string;
  period: string;
  description: string;
  skills: string[];
}

const experiences: Experience[] = [
  // Placeholder for future experiences
  {
    title: "Add Your Future Experience",
    company: "Company Name",
    period: "Start Date - End Date",
    description: "This section will showcase your professional experiences and internships.",
    skills: ["Relevant", "Skills", "Will", "Appear", "Here"]
  }
];

export function ExperienceSection() {
  return (
    <section id="experience" className="space-y-6">
      <SectionHeader title="Professional Experience" icon={Briefcase} />
      <div className="space-y-6">
        {experiences.map((exp, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.2 }}
          >
            <Card className="p-6 hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-background/50 via-background to-background/50">
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-semibold bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
                    {exp.title}
                  </h3>
                  <p className="text-lg text-muted-foreground">{exp.company}</p>
                  <p className="text-sm text-muted-foreground">{exp.period}</p>
                </div>
                <p className="text-base leading-relaxed">{exp.description}</p>
                <div className="flex flex-wrap gap-2">
                  {exp.skills.map((skill) => (
                    <Badge 
                      key={skill}
                      variant="outline"
                      className="hover:bg-primary/10"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  );
}