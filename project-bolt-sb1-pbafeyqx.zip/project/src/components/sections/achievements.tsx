import { Trophy, ExternalLink } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SectionHeader } from '../ui/section-header';
import { achievements } from '@/data/achievements';

export function AchievementsSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Achievements" icon={Trophy} />
      <div className="grid gap-4 md:grid-cols-2">
        {achievements.map((achievement, index) => (
          <Card key={index} className="p-6 group hover:shadow-lg transition-all duration-300">
            <div className="flex justify-between items-start">
              <div className="space-y-2">
                <h3 className="font-semibold group-hover:text-primary transition-colors">
                  {achievement.title}
                </h3>
                <p className="text-sm text-muted-foreground">{achievement.organization}</p>
                <p className="text-sm">{achievement.description}</p>
              </div>
              <a
                href={achievement.certificateUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80 transition-colors"
              >
                <Button variant="ghost" size="icon">
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </a>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}