import { Heart } from 'lucide-react';
import { SectionHeader } from '../ui/section-header';
import { SkillCard } from './skills/skill-card';
import { skillCategories } from '@/data/skills';

export function SkillsSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Skills & Interests" icon={Heart} />
      <div className="grid gap-4 md:grid-cols-2">
        {skillCategories.map((category) => (
          <SkillCard
            key={category.title}
            title={category.title}
            skills={category.skills}
          />
        ))}
      </div>
    </section>
  );
}