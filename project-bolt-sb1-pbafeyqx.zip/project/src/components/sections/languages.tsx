import { Languages } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { SectionHeader } from '../ui/section-header';

export function LanguagesSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Languages" icon={Languages} />
      <Card className="p-6">
        <div className="flex gap-4">
          {["English", "Tamil"].map((lang) => (
            <Badge 
              key={lang} 
              variant="secondary" 
              className="p-2 hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              {lang}
            </Badge>
          ))}
        </div>
      </Card>
    </section>
  );
}