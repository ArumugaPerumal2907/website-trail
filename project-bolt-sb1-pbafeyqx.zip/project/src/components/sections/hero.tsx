import { Mail, Phone, Linkedin, MapPin, FileDown } from 'lucide-react';
import { ContactItem } from '../ui/contact-item';
import { Button } from '@/components/ui/button';
import { ProfileAvatar } from '../ui/profile-avatar';

const CONTACT_INFO = {
  email: {
    text: "arumugaperumal.professional@gmail.com",
    href: "mailto:arumugaperumal.professional@gmail.com"
  },
  phone: {
    text: "7010754100",
    href: "tel:+917010754100"
  },
  linkedin: {
    text: "arumuga-perumal-b63207246",
    href: "https://www.linkedin.com/in/arumuga-perumal-b63207246"
  },
  location: {
    text: "Palayamkottai, Tirunelveli",
    href: "https://maps.app.goo.gl/XUS2QWpXEC62Kf5H6?g_st=ac"
  }
};

const RESUME_URL = "https://drive.google.com/file/d/your-resume-file-id/view?usp=sharing"; // Replace with your resume URL
const PROFILE_IMAGE_URL = "https://blob:https://web.whatsapp.com/b3347ccf-0558-464b-806b-062acfe10189"; // Replace with your profile image URL

export function HeroSection() {
  return (
    <section className="flex flex-col items-center text-center space-y-4 py-12">
      <ProfileAvatar 
        imageUrl={PROFILE_IMAGE_URL}
        fallback="AP"
      />
      <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-primary/80 to-primary bg-clip-text text-transparent">
        Arumuga Perumal S
      </h1>
      <p className="text-xl text-muted-foreground max-w-2xl">
        An enthusiastic UX/UI designer and computer science student passionate about creating impactful digital experiences.
      </p>
      <div className="flex gap-4 flex-wrap justify-center">
        <ContactItem icon={Mail} {...CONTACT_INFO.email} />
        <ContactItem icon={Phone} {...CONTACT_INFO.phone} />
        <ContactItem icon={Linkedin} {...CONTACT_INFO.linkedin} />
        <ContactItem icon={MapPin} {...CONTACT_INFO.location} />
      </div>
      <a
        href={RESUME_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-4"
      >
        <Button 
          className="bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <FileDown className="mr-2 h-4 w-4" />
          Download Resume
        </Button>
      </a>
    </section>
  );
}