import { Book } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { SectionHeader } from '../ui/section-header';

interface EducationCardProps {
  title: string;
  school: string;
  period: string;
  score: string;
}

function EducationCard({ title, school, period, score }: EducationCardProps) {
  return (
    <Card className="p-4">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-muted-foreground">{school}</p>
      <p className="text-sm text-muted-foreground">{period}</p>
      <p className="text-sm font-medium">{score}</p>
    </Card>
  );
}

export function EducationSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Education" icon={Book} />
      <div className="grid gap-4 md:grid-cols-3">
        <EducationCard
          title="Bachelor of Computer Science"
          school="Einstein College of Arts & Science"
          period="Aug 2022 – May 2025"
          score="CGPA: 7.9 (up to 4th semester)"
        />
        <EducationCard
          title="HSC"
          school="Servite Matriculation Higher Secondary School"
          period="June 2020 – May 2022"
          score="Score: 472/600 (78%)"
        />
        <EducationCard
          title="SSLC"
          school="St. Joseph Matriculation School"
          period="June 2019 – May 2020"
          score="Score: 394/500 (78%)"
        />
      </div>
    </section>
  );
}