import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";

interface SkillCardProps {
  title: string;
  skills: string[];
}

export function SkillCard({ title, skills }: SkillCardProps) {
  return (
    <Card className="p-6 hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-background/50 via-background to-background/50">
      <h3 className="text-lg font-semibold mb-4 bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
        {title}
      </h3>
      <div className="flex flex-wrap gap-3">
        {skills.map((skill, index) => (
          <motion.div
            key={skill}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Badge 
              variant="outline"
              className="hover:bg-gradient-to-r hover:from-primary hover:via-purple-500 hover:to-pink-500 hover:text-primary-foreground transition-all duration-300 py-1.5"
            >
              {skill}
            </Badge>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}