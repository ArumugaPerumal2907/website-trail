import { GraduationCap, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SectionHeader } from '../ui/section-header';
import { certifications } from '@/data/certifications';
import { motion } from 'framer-motion';

export function CertificationsSection() {
  return (
    <section className="space-y-4">
      <SectionHeader title="Certifications" icon={GraduationCap} />
      <div className="grid gap-4 md:grid-cols-2">
        {certifications.map((cert, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-4 hover:shadow-md transition-shadow group">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium group-hover:text-primary transition-colors">
                    {cert.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                  {cert.score && (
                    <Badge variant="secondary" className="mt-2">{cert.score}</Badge>
                  )}
                </div>
                <a 
                  href={cert.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80 transition-colors"
                >
                  <Button variant="ghost" size="icon">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </a>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  );
}