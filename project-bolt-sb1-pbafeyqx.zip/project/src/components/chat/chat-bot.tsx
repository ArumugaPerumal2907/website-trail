import { useState } from 'react';
import { MessageSquare, Send, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { motion, AnimatePresence } from 'framer-motion';
import { useChat } from '@/lib/chat/use-chat';

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const { messages, sendMessage } = useChat();

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input);
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      <Button
        className="fixed bottom-4 right-4 rounded-full w-12 h-12 p-0 shadow-lg hover:shadow-xl transition-shadow z-50"
        onClick={() => setIsOpen(true)}
        aria-label="Open chat"
      >
        <MessageSquare className="w-6 h-6" />
      </Button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed bottom-20 right-4 w-[calc(100vw-2rem)] sm:w-[350px] max-w-[400px] z-50"
          >
            <Card className="overflow-hidden shadow-xl">
              <div className="p-4 border-b bg-gradient-to-r from-primary via-purple-500 to-pink-500 text-primary-foreground flex justify-between items-center">
                <h3 className="font-semibold">Chat with Me</h3>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="text-primary-foreground hover:text-primary-foreground/80"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="h-[60vh] sm:h-96 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-background to-background/50">
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`rounded-lg px-4 py-2 max-w-[80%] ${
                        msg.isBot 
                          ? 'bg-muted text-muted-foreground' 
                          : 'bg-gradient-to-r from-primary via-purple-500 to-pink-500 text-primary-foreground'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="p-4 border-t bg-background flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type a message..."
                  className="flex-1"
                />
                <Button 
                  onClick={handleSend} 
                  size="icon"
                  className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 text-primary-foreground"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}