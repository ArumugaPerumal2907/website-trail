import { ModeToggle } from './mode-toggle';

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-background">
      <header className="fixed top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between">
          <span className="text-lg font-bold bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
            Arumuga Perumal S
          </span>
          <ModeToggle />
        </div>
      </header>
      <main className="container mx-auto px-4 pt-20 pb-16 sm:px-6 lg:px-8">
        {children}
      </main>
    </div>
  );
}