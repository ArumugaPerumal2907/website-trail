import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface ContactItemProps {
  icon: LucideIcon;
  text: string;
  href?: string;
  className?: string;
}

export function ContactItem({ icon: Icon, text, href, className }: ContactItemProps) {
  const content = (
    <div className={cn(
      "flex items-center gap-2 px-4 py-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors",
      className
    )}>
      <Icon className="h-4 w-4" />
      <span className="text-sm">{text}</span>
    </div>
  );

  if (href) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className="hover:text-primary transition-colors"
      >
        {content}
      </a>
    );
  }

  return content;
}