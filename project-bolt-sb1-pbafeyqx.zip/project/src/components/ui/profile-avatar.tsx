import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

interface ProfileAvatarProps {
  imageUrl: string;
  fallback: string;
}

export function ProfileAvatar({ imageUrl, fallback }: ProfileAvatarProps) {
  return (
    <div className="relative">
      <Avatar className="w-32 h-32 border-4 border-primary">
        <AvatarImage src={imageUrl} alt="Profile picture" />
        <AvatarFallback>{fallback}</AvatarFallback>
      </Avatar>
      <div className="absolute inset-0 w-32 h-32 rounded-full bg-gradient-to-r from-primary to-primary/80 blur-lg opacity-50 -z-10" />
    </div>
  );
}