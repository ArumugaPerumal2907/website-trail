import { HeroSection } from './sections/hero';
import { ObjectiveSection } from './sections/objective';
import { EducationSection } from './sections/education';
import { ExperienceSection } from './sections/experience';
import { ProjectsSection } from './sections/projects';
import { AchievementsSection } from './sections/achievements';
import { CertificationsSection } from './sections/certifications';
import { SkillsSection } from './sections/skills';
import { LanguagesSection } from './sections/languages';
import { ChatBot } from './chat/chat-bot';

export function Home() {
  return (
    <div className="max-w-4xl mx-auto space-y-16 sm:space-y-24">
      <HeroSection />
      <ObjectiveSection />
      <EducationSection />
      <ExperienceSection />
      <ProjectsSection />
      <AchievementsSection />
      <CertificationsSection />
      <SkillsSection />
      <LanguagesSection />
      <ChatBot />
    </div>
  );
}