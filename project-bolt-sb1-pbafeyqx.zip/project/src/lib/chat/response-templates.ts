import { personalInfo } from './chat-data';

export const responseTemplates = {
  greeting: () => 
    `Hello! I'm ${personalInfo.name}'s virtual assistant. How can I help you today?`,
    
  contact: () => 
    `You can reach Arumuga through:\n` +
    `📧 Email: ${personalInfo.contact.email}\n` +
    `📱 Phone: ${personalInfo.contact.phone}\n` +
    `📍 Address: ${personalInfo.contact.address}\n` +
    `💼 LinkedIn: ${personalInfo.contact.linkedin}`,
    
  education: (type?: 'all' | 'ug' | 'hsc' | 'sslc') => {
    switch(type) {
      case 'ug':
        return `Currently pursuing ${personalInfo.education.bachelors.degree} at ${personalInfo.education.bachelors.institution} (${personalInfo.education.bachelors.period}) with ${personalInfo.education.bachelors.score}`;
      case 'hsc':
        return `Completed HSC at ${personalInfo.education.hsc.school} with ${personalInfo.education.hsc.score} in ${personalInfo.education.hsc.stream}`;
      case 'sslc':
        return `Completed SSLC at ${personalInfo.education.sslc.school} with ${personalInfo.education.sslc.score}`;
      default:
        return `Education Background:\n` +
          `🎓 UG: ${personalInfo.education.bachelors.degree} (${personalInfo.education.bachelors.score})\n` +
          `📚 HSC: ${personalInfo.education.hsc.score}\n` +
          `📚 SSLC: ${personalInfo.education.sslc.score}`;
    }
  },
  
  skills: (type?: 'technical' | 'non-technical') => {
    const technical = ["Java", "HTML", "CSS", "UI basics", "Wireframing", "SQL basics"];
    const nonTechnical = ["Soft skills", "Collaboration", "Time management", "Agile basic workflow"];
    
    switch(type) {
      case 'technical':
        return `Technical skills include: ${technical.join(', ')}`;
      case 'non-technical':
        return `Non-technical skills include: ${nonTechnical.join(', ')}`;
      default:
        return `Skills Overview:\n` +
          `💻 Technical: ${technical.join(', ')}\n` +
          `🤝 Non-Technical: ${nonTechnical.join(', ')}`;
    }
  },
  
  project: () => 
    `Current Project: Just Stitch (Sep 2024)\n` +
    `A virtual platform connecting consumers and tailors featuring:\n` +
    `• Peer-to-peer networking\n` +
    `• Order status tracking\n` +
    `• Design trend exploration\n` +
    `• Community forum for discussions`,
    
  achievements: () => 
    `Notable Achievements:\n` +
    `🏆 1st Prize in Dawn State Level Symposium (Topic: Greener Future Ecosystem)\n` +
    `🎯 XPASO Participation (Topics: IoT, AR/VR)`,
    
  certifications: () => 
    `Certifications:\n` +
    `• UX/UI & Product Design Architecture (IIT Roorkee) - 79%\n` +
    `• Design Enterprise Thinking Practitioner (IBM)\n` +
    `• Behavioral Skills (Infosys Springboard)\n` +
    `• Design Thinking (Infosys Springboard)\n` +
    `• Basic Code Development (CSC Institutions)\n` +
    `• Python Basics (Apollo Institutions)\n` +
    `• PowerPoint Badge (LinkedIn)`,
    
  languages: () => 
    `Languages: ${personalInfo.languages.join(', ')}`,
    
  interests: () => 
    `Areas of Interest: ${personalInfo.interests.join(', ')}`,
};