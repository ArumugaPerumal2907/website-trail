import { responseTemplates } from './response-templates';

interface ChatResponse {
  keywords: string[];
  response: string | (() => string);
  followUp?: string[];
}

export const chatResponses: ChatResponse[] = [
  {
    keywords: ['hello', 'hi', 'hey', 'start', 'help'],
    response: responseTemplates.greeting,
    followUp: ['Would you like to know about education, skills, projects, or contact information?']
  },
  {
    keywords: ['contact', 'email', 'phone', 'address', 'reach', 'linkedin'],
    response: responseTemplates.contact,
    followUp: ['Is there anything specific you\'d like to know about Arumuga\'s background?']
  },
  {
    keywords: ['education', 'study', 'college', 'school', 'university', 'degree', 'ug', 'hsc', 'sslc'],
    response: responseTemplates.education,
    followUp: ['Would you like specific details about UG, HSC, or SSLC?']
  },
  {
    keywords: ['skills', 'abilities', 'technologies', 'tech', 'programming', 'development'],
    response: responseTemplates.skills,
    followUp: ['Would you like to know more about technical or non-technical skills?']
  },
  {
    keywords: ['project', 'just stitch', 'work', 'portfolio'],
    response: responseTemplates.project,
    followUp: ['Would you like to know about achievements or certifications as well?']
  },
  {
    keywords: ['achievements', 'awards', 'recognition', 'accomplishments'],
    response: responseTemplates.achievements,
    followUp: ['Would you like to know about certifications too?']
  },
  {
    keywords: ['certifications', 'certificates', 'courses', 'training'],
    response: responseTemplates.certifications,
    followUp: ['Would you like to know about specific certifications?']
  },
  {
    keywords: ['languages', 'speak', 'communication'],
    response: responseTemplates.languages,
    followUp: ['Would you like to know about other skills?']
  },
  {
    keywords: ['interests', 'hobbies', 'passion'],
    response: responseTemplates.interests,
    followUp: ['Would you like to know more about any specific interest area?']
  }
];