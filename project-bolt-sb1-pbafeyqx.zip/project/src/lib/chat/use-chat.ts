import { useState } from 'react';
import { chatResponses } from './chat-responses';

interface Message {
  text: string;
  isBot: boolean;
}

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([{
    text: "Hi! I'm Arumuga's virtual assistant. How can I help you today?",
    isBot: true
  }]);

  const findResponse = (input: string): { response: string; followUp?: string } => {
    const lowercaseInput = input.toLowerCase();
    
    const matchingResponse = chatResponses.find(response =>
      response.keywords.some(keyword => lowercaseInput.includes(keyword))
    );

    if (!matchingResponse) {
      return {
        response: "I'm not sure about that. Would you like to know about Arumuga's education, skills, projects, or achievements?",
      };
    }

    const responseText = typeof matchingResponse.response === 'function' 
      ? matchingResponse.response()
      : matchingResponse.response;

    return {
      response: responseText,
      followUp: matchingResponse.followUp?.[Math.floor(Math.random() * matchingResponse.followUp.length)]
    };
  };

  const sendMessage = (text: string) => {
    if (!text.trim()) return;

    setMessages(prev => [...prev, { text, isBot: false }]);
    
    setTimeout(() => {
      const { response, followUp } = findResponse(text);
      setMessages(prev => [
        ...prev, 
        { text: response, isBot: true },
        ...(followUp ? [{ text: followUp, isBot: true }] : [])
      ]);
    }, 500);
  };

  return {
    messages,
    sendMessage
  };
};