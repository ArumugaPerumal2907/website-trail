// Structured data about Arumuga
export const personalInfo = {
  name: "Arumuga Perumal S",
  contact: {
    email: "arumugaperumal.professional@gmail.com",
    phone: "7010754100",
    address: "64A/1 Perumal East Car Street, Palayamkottai-Tirunelveli",
    linkedin: "arumuga-perumal-b63207246"
  },
  education: {
    bachelors: {
      degree: "Bachelor of Computer Science",
      institution: "Einstein College of Arts & Science",
      location: "Seethaparpanallur-Tirunelveli",
      period: "Aug 2022 – May 2025",
      score: "CGPA: 7.9 (up to 4th semester)"
    },
    hsc: {
      school: "Servite Matriculation Higher Secondary School",
      location: "Palayamkottai-Tirunelveli",
      period: "June 2020 – May 2022",
      score: "472/600 (78%)",
      stream: "Mathematics, Computer Science"
    },
    sslc: {
      school: "St. Joseph Matriculation School",
      location: "Palayamkottai-Tirunelveli",
      period: "June 2019 – May 2020",
      score: "394/500 (78%)"
    }
  },
  languages: ["English", "Tamil"],
  interests: [
    "Editing",
    "UX brainstorming & ideation",
    "UI cloning"
  ]
};