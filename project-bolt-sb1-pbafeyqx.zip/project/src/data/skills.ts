interface SkillCategory {
  title: string;
  skills: string[];
}

export const skillCategories: SkillCategory[] = [
  {
    title: "Technical Skills",
    skills: [
      "Java",
      "HTML",
      "CSS",
      "UI basics",
      "Wireframing",
      "SQL basics"
    ]
  },
  {
    title: "Non-Technical Skills",
    skills: [
      "Soft skills",
      "Collaboration",
      "Time management",
      "Agile workflow"
    ]
  }
];