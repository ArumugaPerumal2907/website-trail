interface Project {
  title: string;
  description: string;
  features: string[];
  projectUrl: string;
}

export const featuredProject: Project = {
  title: "Just Stitch (Project-in-Process)",
  description: "A virtual platform bridging consumers and tailors, featuring peer-to-peer networking, order tracking, and design trend exploration.",
  features: ["P2P Networking", "Order Tracking", "Design Trends", "Community Forum"],
  projectUrl: "https://github.com/yourusername/just-stitch"
};