interface Certification {
  title: string;
  issuer: string;
  score?: string;
  pdfUrl: string;
}

export const certifications: Certification[] = [
  {
    title: "UX/UI & Product Design Architecture",
    issuer: "IIT Roorkee",
    score: "79%",
    pdfUrl: "https://drive.google.com/file/d/1czkTQ8ePsrIL2TwfvHjs05ntvY4ywWN1/view?usp=drivesdk"
  },
  {
    title: "Design Enterprise Thinking Practitioner",
    issuer: "IBM",
    pdfUrl: "https://drive.google.com/file/d/1d36vrbnlt4BCIu9Dq6WTAxGAro2L1WZ0/view?usp=drivesdk"
  },
  {
    title: "Behavioral Skills",
    issuer: "Infosys Springboard",
    pdfUrl: "https://drive.google.com/file/d/1dUNGAQF4YWGbw0AHII8hChnmByP6Sbxn/view?usp=drivesdk"
  },
  {
    title: "Design Thinking",
    issuer: "Infosys Springboard",
    pdfUrl: "https://drive.google.com/file/d/1OJweR-lekJxYuFkJ9TjjkpM53Be1Ji9d/view?usp=drivesdk"
  },
  {
    title: "Basic Code Development",
    issuer: "CSC Institutions",
    pdfUrl: "https://drive.google.com/file/d/1cbNLFHobFBEkeb9rFPcUVVufUVuhyo0e/view?usp=drivesdk"
  },
  {
    title: "Python Basics",
    issuer: "Apollo Institutions",
    pdfUrl: "https://drive.google.com/file/d/1cfsmRk5QhKv4Mr8_dV6VAEtf2kLApluI/view?usp=drivesdk"
  },
  {
    title: "PowerPoint Badge",
    issuer: "LinkedIn",
  }
];