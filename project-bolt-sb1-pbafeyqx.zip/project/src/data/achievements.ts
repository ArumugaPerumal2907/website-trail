interface Achievement {
  title: string;
  description: string;
  organization: string;
  certificateUrl: string;
}

export const achievements: Achievement[] = [
  {
    title: "Dawn State Level Symposium",
    description: "1st Prize Certified - Topic: Greener Future Ecosystem",
    organization: "FX Engineering College",
    certificateUrl: "https://drive.google.com/file/d/1dquNIO9Cd3DndCboYuILvWBolOKIMPWz/view?usp=drivesdk"
  },
  {
    title: "XPASO-Techno Talks",
    description: "Participation Certified - Topics: IoT, AR/VR",
    organization: "Xavier College Paper Presentation",
    certificateUrl: "https://drive.google.com/file/d/1dvnqQIxNO0mv3rfbLvlHWD7DDsa6zf8a/view?usp=drivesdk"
  }
];